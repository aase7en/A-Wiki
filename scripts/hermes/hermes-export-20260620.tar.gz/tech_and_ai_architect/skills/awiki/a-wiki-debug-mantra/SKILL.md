---
name: a-wiki-debug-mantra
description: "Four-mantra debugging discipline from A-Wiki — reproduce, trace the fail path, falsify the hypothesis, cross-reference every breadcrumb. Enforces Iron Law #2: NO bug fixing without root cause investigation first."
version: 1.0.0
metadata:
  hermes:
    tags: [awiki, debug, root-cause, tdd, iron-law]
---

# Debug Mantra (จาก A-Wiki)

> ⚠️ **IRON LAW #2**: NO BUG FIXING WITHOUT ROOT CAUSE INVESTIGATION FIRST.
> Superficial patching is FORBIDDEN. The four steps below are MANDATORY before any fix.

## Recite this — verbatim ก่อนเริ่ม debug

> **Mantra:**
> 1. **First is reproducibility.** Can the issue be reproduced reliably?
> 2. **Know the fail path.** Debugger first; then source trace + knob enumeration; then in-code instrumentation.
> 3. **Question your hypothesis.** What would disprove it?
> 4. **Every run is a breadcrumb.** Cross-reference all of them.

## 1. Reproduce reliably

สร้าง repro ที่รันได้ก่อนทำอย่างอื่น:

- **Reliable repro** → จับ steps, inputs, environment เป็น artifact: failing test, curl script, CLI invocation
- **Flaky repro** → bug ยัง debug ไม่ได้ → loop trigger, parallelise, add stress, narrow timing, inject sleeps. 50% flake = debuggable; 1% = not.
- **No repro at all** → หยุด บอก user ตรงๆ ถามหา env access, captured artifacts (HAR, log dump, core) ห้ามเดา

Target: fast (1–5 s), deterministic pass/fail signal.

## 2. Know the fail path

หา *ที่* ที่โค้ดพัง และ *อะไร* ที่ทำให้มันไม่พัง:

1. **Attach a debugger.** ถ้า env รองรับ → ก่อนทำอย่างอื่น
2. **Source trace + knob enumeration.** ถ้าไม่มี debugger → trace code path end-to-end + list ทุก knob:
   - config flags, env vars, feature toggles
   - branch conditions, input shape
   - timing, concurrency, build options
   แต่ละ knob = candidate axis → flip ทีละตัว
3. **In-code instrumentation.** ถ้า knob ภายนอกขยับไม่ได้ → printf/log ที่ suspected fail site, tag ด้วย unique prefix (`[DBG-a4f2]`) ให้ cleanup ง่าย

## 3. Falsify the hypothesis

เมื่อ candidate root cause โผล่มา — scrutinize ก่อน test:

- มันอธิบาย symptom end-to-end ได้จริงไหม?
- อะไรคือ simplest **proof**? อะไรคือ cleanest **disproof**?
- รัน **disproof first** → ถ้า hypothesis รอด = จริง ถ้าตาย = หยุดไล่ phantom
- Generate 3–5 ranked hypotheses — อย่ามีแค่หนึ่ง

## 4. Every run is a breadcrumb

รักษา **ledger** ของทุก experiment:

- แต่ละ entry: what changed, what happened, what it ruled in or out
- เมื่อ hypothesis ใหม่โผล่ → walk ledger → มันอธิบายทุก prior observation ได้ไหม?
- ถ้ามี past run ขัดแย้ง → hypothesis ผิดหรือไม่สมบูรณ์ → refine หรือ discard
- Design **single experiment** ที่ผลลัพธ์ทำให้แน่ใจ → รันอันนั้นก่อน

## Operating Rules

- Recite mantra block **once** per debug session, in first response
- Ledger อยู่ใน working memory ระหว่าง session
- ห้ามเสนอ fix โดยยังไม่ครบ 4 ขั้นตอน
- ถ้า subagent/delegate พยายาม patch โดยไม่ทำตามนี้ → DISCARD output → REWRITE
