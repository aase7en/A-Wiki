---
name: a-wiki-core
description: "Bridge between Hermes and A-Wiki — Iron Laws, Cost-First Pyramid, wiki search, cross-agent handoff, session start protocol. Load this when working with A-Wiki knowledge base."
version: 1.2.0
metadata:
  hermes:
    tags: [awiki, wiki, knowledge-base, swarm, iron-laws, cross-agent]
---

# A-Wiki Core — Hermes ↔ A-Wiki Bridge

A-Wiki คือ "สมองกลาง" (Universal AI Brain) ที่ Hermes สามารถอ่าน เขียน ค้นหา
และใช้เป็นฐานความรู้ร่วมกับ AI agents อื่นๆ (Claude Code, Codex, Gemini CLI, Cursor, Cline ฯลฯ)

**A-Wiki path**: `/Users/aase7en/Desktop/A-Wiki`

## Session Start Protocol (ทำทุกครั้งที่ทำงานกับ A-Wiki)

1. อ่าน `wiki/context/wiki-overview.md` — สถิติ + synthesis + pointers
2. อ่าน `wiki/context/session-memory.md` — TODO + การตัดสินใจข้าม session
3. ถ้าไม่มี `session-memory.md` → ใช้ `.example` + รัน `bash scripts/setup-local.sh`

## 🔒 Iron Laws (UNBREACHABLE)

กฎเหล่านี้ Hermes ต้องปฏิบัติตามเมื่อทำงานกับ A-Wiki:

1. **NO production code without a failing test first**
2. **NO bug fixing without root cause first** (debug-mantra 4-step)
3. **If parallel model violates #1 or #2 → DISCARD and REWRITE**
4. **`raw/` is immutable** — never edit or delete
5. **Config files (AGENTS.md, CLAUDE.md) must not be edited without explicit permission**
6. **External-editor source-of-truth protection** — check `USERSCRIPT_SYNC_OK` before editing files maintained outside git
7. **Source provenance — `raw/` first, always** — save raw content to `raw/<slug>.<ext>` BEFORE creating `wiki/sources/<slug>.md`
8. **Bot trading client is MOCK/visualization-only** — no secrets, signed requests, or order execution
9. **Storage decision**: personal/secret/machine-specific → `drive/`; reusable knowledge → repo

## 💰 Cost-First Decision Pyramid

เริ่มจากระดับต่ำสุดเสมอ ขยับขึ้นเมื่อระดับล่างทำไม่ได้:

| Level | Channel | Use for |
|-------|---------|---------|
| **-1** | Local FTS5 / knowledge-graph | Free + offline — search wiki |
| **0** | Hook + Context Compaction | Free — repeated tasks |
| **1** | `free-current` dynamic roster | Free — search, lookup, synthesis |
| **2** | `cheap-capable` runtime route | Very cheap — light reasoning |
| **3** | `platform-low-scout` / low-cost CLI agent | Cheap — scan many files |
| **4** | `platform-primary` current model | Normal — complex reasoning only after scout says lower tiers insufficient |

## Wiki Search (Level -1, ฟรี)

```bash
# FTS5 full-text search
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/wiki/search-wiki.py "query"

# Knowledge graph hubs
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/wiki/query-graph.py --hubs
```

## Wiki Context Files (Fast Load)

| File | ใช้เมื่อ |
|------|--------|
| `wiki/context/wiki-overview.md` | เริ่ม session — abstract ทุกหน้า |
| `wiki/context/knowledge-graph.md` | ต้องการ relationships |
| `wiki/context/session-memory.md` | ข้าม session decisions + TODOs |
| `wiki/context/overview-iot.md` | งาน IoT |
| `wiki/context/overview-env.md` | งาน Environmental Health |
| `wiki/context/overview-ai-tools.md` | งาน AI Tools |
| `wiki/context/overview-pharmacy.md` | งาน Pharmacy |

## Knowledge Domains

| Domain | Index | Status |
|--------|-------|--------|
| IoT | `index-iot.md` | ✅ 34 entities, 11 concepts |
| Environmental Health | `index-env.md` | ✅ entities + concepts |
| AI Tools | `index-ai-tools.md` | ✅ entities + concepts |
| Pharmacy | `index-pharmacy.md` | ✅ 3,760 SKU |
| IT Support | `index-it.md` | 🆕 1 concept |

## Cross-Agent Handoff Protocol

เมื่อทำงานต่อจาก agent อื่น หรือต้องส่งต่องาน:

1. `git pull --ff-only origin main`
2. อ่าน `handoff.md` — ดู task context, uncommitted changes, pending TODOs
3. ทำงานตามขั้นตอนที่ค้างอยู่
4. Commit: `type(scope): description [step N/M]`
5. Push เมื่อถึง handoff boundary
6. อัปเดต `handoff.md` และ `wiki/context/session-memory.md`

**Commit message format**: `type(scope): description`
- Types: `feat` · `fix` · `docs` · `wiki` · `refactor` · `test` · `chore`

## Wiki Health Scripts

```bash
# Health check
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/gen-index.py --check

# Full index regeneration
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/gen-index.py

# Agent preflight safety check
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/agent-preflight.py

# Privacy check before commit
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/check-privacy.py
```

## Confidence Markers

ทุกหน้าต้องมี marker อย่างน้อยหนึ่งอัน:
- `[training]` — มาจาก training data
- `[verified YYYY-MM-DD]` — ตรวจสอบแล้ววันที่
- `[wiki]` — สร้างจาก wiki knowledge
- `[notebooklm YYYY-MM-DD]` — จาก NotebookLM

## Output Format (3-layer)

1. **Layer 1** — durable knowledge → **Markdown** (git-diffable)
2. **Layer 2** — machine↔machine → **compact**: CSV/TSV > JSONL > JSON (never HTML)
3. **Layer 3** — human review → JSON → render-html → gitignored leaf in `exports/html/`

## Kilo Plan Implementation Workflow

เมื่อพบแผนใน `.kilo/plans/*.md` (จาก Kilo AI Plan Mode):

1. อ่าน plan → ดู phases + dependency order
2. สร้าง todo list (1 item ต่อ 1 requirement)
3. Implement ทีละ phase → อ่านไฟล์ที่ต้องแก้ก่อน → สร้างไฟล์ใหม่ → patch ไฟล์ที่มีอยู่
4. หลังแต่ละ phase → อัปเดต `wiki/context/session-memory.md` ด้วย progress
5. ใช้ `todo` tool เพื่อ track status (`pending` → `in_progress` → `completed`)
6. Phase ที่เหลือ → บันทึกลง session-memory.md เพื่อให้ session ถัดไป (หรือ Claude Code/Gemini) มาทำต่อ

**Key pattern**: อ่านไฟล์ใหญ่ด้วย `/usr/bin/python3` heredocs เมื่อ `read_file` tool มีปัญหา (ไฟล์ >100KB หรือ path มี character พิเศษ)

## Hermes Cron Jobs for A-Wiki

| Job ID | Name | Schedule | Purpose |
|--------|------|----------|---------|
| `224a5351605a` | A-Wiki Daily Health Check | ทุกวัน 08:00 | Wiki structure + agent preflight + git status + stale tasks + stats |

จัดการด้วย: `cronjob(action='list')`, `cronjob(action='run', job_id='224a5351605a')`

## Live Dashboard

A-Wiki Live Dashboard รันที่ `http://localhost:7790` — real-time monitoring ของ swarm activity, hooks, models

### Server Management

```bash
# Start foreground (เห็น logs)
/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/live-dashboard/server.py --run

# Start background (Hermes)
terminal(command="/usr/bin/python3 /Users/aase7en/Desktop/A-Wiki/scripts/live-dashboard/server.py --run", background=True, timeout=300)

# Stop
process(action='kill', session_id='<id>')
```

### Endpoint Testing (เมื่อ `curl` ไม่可用จาก PATH issue)

```python
import urllib.request, json

# GET status
with urllib.request.urlopen('http://localhost:7790/status') as r:
    print(json.loads(r.read()))

# POST chat message
body = json.dumps({'message': 'hello', 'from': 'hermes'}).encode()
req = urllib.request.Request('http://localhost:7790/api/chat', data=body,
    headers={'Content-Type': 'application/json'}, method='POST')
with urllib.request.urlopen(req) as r:
    print(json.loads(r.read()))
```

### Endpoint Reference

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/` | Dashboard HTML |
| GET | `/status` | Server status JSON |
| GET | `/events` | SSE stream |
| GET | `/clear` | Clear event log |
| GET | `/api/models` | Model config |
| POST | `/api/models` | Save model config |
| GET | `/api/keys` | API key status |
| POST | `/api/keys` | Save API key |
| GET | `/api/capabilities` | Model capability scores |
| GET | `/api/graph` | Workflow graph state |
| GET | `/api/admin/status` | Admin password status |
| POST | `/api/admin/auth` | Admin login |
| GET | `/api/agents` | Agent types registry + config |
| POST | `/api/agents` | Save agent config |
| POST | `/api/agents/reorder` | Update agent order |
| POST | `/api/chat` | Send chat message → persist + broadcast SSE |
| POST | `/api/upload` | Upload file (multipart) |
| GET | `/api/uploads/<name>` | Serve uploaded file |

### Chat Integration with Hermes

Hermes สามารถส่งข้อความไปแสดงบน Dashboard ผ่าน Chat endpoint:

```python
# ส่งข้อความแจ้งเตือนไปที่ Dashboard
urllib.request.urlopen(urllib.request.Request(
    'http://localhost:7790/api/chat',
    data=json.dumps({'message': '✅ Task complete', 'from': 'hermes'}).encode(),
    headers={'Content-Type': 'application/json'},
    method='POST'
))
```

ข้อความจะถูก persist ใน `.tmp/chat-log.jsonl` และ broadcast ผ่าน SSE ให้ทุก client ที่เชื่อมต่อ

### Themes

Dashboard มี 2 ธีม (เพิ่มจากเดิม light/dark):
- **Green-White** ☀ — `data-theme="green-white"` — พื้นหลังขาว เขียวสะอาด
- **Black-Neon** 🌙 — `data-theme="black-neon"` — พื้นดำ เขียวนีออนสว่าง

CSS custom properties อยู่ใน `scripts/live-dashboard/live-dashboard.html` — แก้ธีมโดยเปลี่ยน color palette ใน `:root` / `[data-theme="..."]`

## Running A-Wiki Hooks Directly

A-Wiki hooks (`scripts/hooks/`) ออกแบบสำหรับ Claude Code PreToolUse แต่ Hermes รัน hooks.py CLI ตรงๆ ได้:

```bash
HOOKS="/Users/aase7en/Desktop/A-Wiki/agent-skills/automations/hooks.py"

# Pre-flight checks (validate git origin + main branch)
/usr/bin/python3 $HOOKS pre-flight

# Session start routine
/usr/bin/python3 $HOOKS session-start

# Session end routine (scan debug prints + commit summary)
/usr/bin/python3 $HOOKS session-end

# Write session summary to .local/session-memory.md
/usr/bin/python3 $HOOKS summary "title" "status" "context" "next_action"
```

ดูรายละเอียดเพิ่มเติม: `references/merge-safety.md` — รวมถึง CSS/JS injection safety (ห้าม inject เข้าใน theme block; ให้ inject ก่อน `</style>` / `</script>`)

## Session References

- `references/merge-safety.md` — **CRITICAL**: never `git reset --soft` without inspecting remote. Recovery recipe for merge conflicts and CSS/JS injection safety. Read this before any git operation on A-Wiki.
- `references/awiki-customization-session-2026-06-19.md` — Full implementation summary of the A-Wiki customization plan (14 new files, 3 modified, all endpoints tested)

## User Preferences for Dashboard

- **Incremental additions only**: เพิ่มของใหม่บนของเดิมที่ทำงานอยู่ — ห้ามเขียนทับ dashboard ด้วยเวอร์ชันของตัวเอง
- **Flow View icons**: ใช้ถ้วยรางวัลแชมเปี้ยน (🏆) สำหรับทุก model station — CSS ปรับให้ตรงกลางด้วย `display:flex;align-items:center;justify-content:center`
- **Drag-and-drop location**: ลากในหน้า Flow View โดยตรง (ไม่ใช่แค่ใน Settings panel) — SortableJS บน `#flow-overlay`
- **ถ้าผู้ใช้บอกว่า "มั่ว"**: หยุด patch — restore clean จาก git → เริ่มใหม่ incremental

## External Data Layer

- `drive/` = Google Drive symlink — private data, secrets, heavy files (gitignored)
- `raw/` = immutable source documents (symlink → drive/raw/)
- `A_WIKI_DRIVE_PATH` = env var for explicit path resolution
- **Hard rule**: never write machine-specific paths into public repo

## Dashboard Modification Protocol

เมื่อต้องแก้ไข `scripts/live-dashboard/live-dashboard.html` (หรือไฟล์ใหญ่ที่ maintained โดยหลาย agent):

1. **เริ่มจาก clean remote เสมอ**: `git show origin/main:scripts/live-dashboard/live-dashboard.html` → เช็คขนาดและความสมบูรณ์ก่อน
2. **Add, don't replace**: เพิ่ม CSS ก่อน `</style>`, เพิ่ม JS ก่อน `</script>`, เพิ่ม HTML ก่อน `</body>` — ห้ามลบของเดิม
3. **ทีละอย่าง**: เพิ่ม feature เดียว → รีสตาร์ท server → ทดสอบด้วย browser_console → เช็ค 0 error → ค่อยทำต่อ
4. **Inject ผิดที่ = พัง**: CSS ใน theme block = ใช้ได้เฉพาะ theme นั้น, JS ก่อน function ที่ไม่มี = ไม่ถูก insert เลย ดู `references/merge-safety.md` §CSS/JS Injection Safety
5. **ถ้าผู้ใช้บอกว่า "มั่ว"**: หยุด patch — `git show <good-commit>:file` → restore clean → เริ่มใหม่แบบ incremental

### Tool fallback when `write_file` / `patch` fail

บน Mac เครื่องนี้ PATH มีปัญหา (`${PATH}` literal ไม่ expand) → `write_file`, `patch`, `read_file` tools ล้มเหลวเพราะเรียก `cat`, `rm`, `rg` ไม่เจอ

**Workaround — ใช้ `/usr/bin/python3` แทนทุกกรณี:**

```bash
# สร้างไฟล์ใหม่
/usr/bin/python3 << 'PYEOF'
content = '''...file content...'''
with open('target/path', 'w') as f:
    f.write(content)
PYEOF

# แก้ไขไฟล์ (find-and-replace)
/usr/bin/python3 -c "
with open('target/path') as f:
    html = f.read()
html = html.replace('old_string', 'new_string')
with open('target/path', 'w') as f:
    f.write(html)
"

# อ่านไฟล์
/usr/bin/python3 -c "
with open('target/path') as f:
    print(f.read()[:5000])
"
```

**Pattern สำหรับไฟล์ใหญ่ (>100KB)**: ใช้ Python batch-read + replace แทน `patch` tool — `patch` tool อ่านไฟล์ใหญ่ไม่ไหว

### `.gitignore` patterns blocking intentional files

A-Wiki `.gitignore` มี `*token*` และ `*password*` patterns → ไฟล์อย่าง `check_token_waste.py` และ `set-admin-password.py` ถูก block ไม่ให้ `git add`

**Fix**: `git add -f <file>` เพื่อ force-add ไฟล์ที่มีชื่อตรงกับ gitignore pattern

### Git push rejected — remote diverged

เมื่อ remote มี commit ใหม่ที่ local ไม่มี → `git push` ถูก reject ด้วย `non-fast-forward`

**Resolution pattern**:
1. `git fetch origin main` — ดูว่า remote มีอะไรใหม่
2. `git reset --soft origin/main` — ย้าย HEAD ไปที่ remote โดยเก็บ changes ไว้ staged
3. `git reset HEAD <unrelated-files>` — unstage ไฟล์ที่ไม่เกี่ยวกับงานเรา
4. `git commit -m "..."` — commit ใหม่บน origin/main
5. `git push origin main` — push สำเร็จ

**⚠️ ห้าม `git push --force` บน main** — A-Wiki Iron Law

### 🚨 CRITICAL: `git reset --soft` สามารถเขียนทับของดีโดยไม่รู้ตัว

เมื่อ local branch diverge จาก remote และใช้ `git reset --soft origin/main` เพื่อ sync — **ทุกไฟล์ที่ local แก้ไขจะถูก stage ทับของบน remote โดยไม่มีการตรวจสอบ**

**Real incident (2026-06-19)**: `git reset --soft origin/main` เขียนทับ `live-dashboard.html` เวอร์ชัน 89K (elevation-based dark theme, gradient headers, glow effects, full chat system) ด้วยเวอร์ชัน 64K ที่เรียบง่ายกว่า → ผู้ใช้เห็น dashboard "เพี้ยน" — สูญเสีย 1,349 บรรทัดของ CSS/JS ที่สวยงาม

**🚨 If user says "มั่ว" / "เพี้ยน" / "ไม่สวยเหมือนเดิม" — STOP PATCHING**: อย่าพยายาม patch ซ้ำบนของที่พัง — restore clean version จาก git ก่อน (`git show <good-commit>:file`), verify มันสวยและใช้งานได้, แล้วค่อยเพิ่มของใหม่ทีละอย่างแบบ incremental พร้อมทดสอบทุก step

**BEFORE any `git reset --soft`**:
```bash
# 1. ดูว่า remote มีไฟล์อะไรที่ local ก็แก้ไขด้วย
/usr/bin/git -C /path/to/A-Wiki diff --name-only origin/main

# 2. สำหรับทุกไฟล์ที่ overlap — ตรวจสอบ remote version ก่อน
/usr/bin/git -C /path/to/A-Wiki show origin/main:path/to/file | head -50

# 3. ถ้า remote version ดีกว่า (สวยกว่า, มี feature มากกว่า) — ใช้ remote เป็น base
#    แล้ว re-apply การเปลี่ยนแปลงของเราแบบ manual

# 4. NEVER reset --soft โดยไม่เข้าใจว่า remote version มีอะไร
```

**Safe reset pattern** (เมื่อมั่นใจว่า remote version คือ base ที่ถูกต้อง):
```bash
git fetch origin main
git show origin/main:critical-file  # ตรวจสอบก่อนเสมอ!
git reset --soft origin/main        # ทำเมื่อมั่นใจแล้วเท่านั้น
git reset HEAD unrelated-files      # unstage ไฟล์ที่ไม่ใช่ของเรา
git commit -m "..."                  # commit บน base ที่ถูกต้อง
git push origin main
```

**สำหรับไฟล์ UI/HTML/CSS โดยเฉพาะ**: ห้ามคิดว่า version ของเราดีกว่า — A-Wiki dashboard ผ่านการพัฒนาและ polish มาหลาย session จากหลาย agent ควร preserve การปรับปรุงที่มีอยู่แล้ว

ดูรายละเอียดเพิ่มเติม: `references/merge-safety.md`
