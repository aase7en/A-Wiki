# Merge Safety — Critical Protocol

> **Incident**: 2026-06-19 — `git reset --soft origin/main` overwrote 89K polished dashboard with 64K simpler version. User saw broken UI. 1,349 lines lost.

## The Golden Rule

**Never `git reset --soft` without inspecting remote file contents first.**

## BEFORE any reset/pull that could overwrite local changes

```bash
# 1. See what files differ between local and remote
/usr/bin/git -C /path/to/A-Wiki diff --name-only origin/main

# 2. For EVERY overlapping file — inspect remote version
/usr/bin/git -C /path/to/A-Wiki show origin/main:path/to/file | /usr/bin/python3 -c "
import sys; print(f'Remote: {len(sys.stdin.read())} chars')"

# 3. If remote is BETTER (more chars, more features) — use it as base
```

## Safe Reset Pattern

```bash
git fetch origin main
# ⚠️ INSPECT remote files FIRST (see above)
git reset --soft origin/main        # Only when confident
git reset HEAD unrelated-files      # Unstage what's not yours
git commit -m "..."
git push origin main
```

## CSS/JS Injection Safety

When patching large HTML files:

| ✅ DO THIS | ❌ NOT THIS |
|-----------|------------|
| Add CSS right before `</style>` | Inject inside a theme block `{}` |
| Add JS right before `</script>` | Insert before a non-existent function |
| Add HTML right before `</body>` | Insert inside another div without closing |
| Test with browser_console after each change | Make 10 changes then test |
| Use `/usr/bin/python3` heredocs to write files | Rely on `write_file`/`patch` tools on broken PATH |

## Recovery Recipe (when user says "มั่ว" / "เพี้ยน")

```
git show <good-commit-hash>:path/to/file > path/to/file
# Restart server
# Verify with browser — 0 errors in console
# Then add changes ONE at a time, testing each
```

## Key Lesson

**Add, don't replace.** The A-Wiki dashboard was polished over many sessions by multiple agents. Your changes should be incremental additions, never wholesale replacements.
