---
name: a-wiki-git-safety
description: "Git safety protocol from A-Wiki — validate remote origin, solo-main (no branches/PRs), pre-commit validation, cross-device continuity. Use when working in A-Wiki repository."
version: 1.0.0
metadata:
  hermes:
    tags: [awiki, git, safety, cross-device, commit-discipline]
---

# Git Safety (จาก A-Wiki)

ใช้เมื่อทำงานภายใน A-Wiki repository (`/Users/aase7en/Desktop/A-Wiki`)

## 🔒 Rule 1: Validate Remote Origin ก่อน Execute

**MANDATORY ก่อนแก้โค้ด:**

```bash
git -C /Users/aase7en/Desktop/A-Wiki remote -v
git -C /Users/aase7en/Desktop/A-Wiki branch --show-current
```

ถ้า `origin` ชี้ผิดที่:
1. **STOP.** ห้าม execute
2. **FLAG** แจ้ง user
3. **ห้ามแก้** git config โดยไม่ได้รับอนุญาต

## 🔒 Rule 2: Solo Main — No Branch, No PR

```
🚫 NO branch creation
🚫 NO pull request
🚫 NO worktree isolation
✅ COMMIT DIRECTLY TO main ONLY
```

## 🔒 Rule 3: Session Carry-Over

หลัง session สำคัญ → อัปเดต cross-session context:

1. อัปเดต `wiki/context/session-memory.md` ด้วย:
   - สิ่งที่ทำสำเร็จ
   - TODOs ที่เหลือ
   - การตัดสินใจสำคัญ

2. Commit + push:
```bash
git -C /Users/aase7en/Desktop/A-Wiki add -A
git -C /Users/aase7en/Desktop/A-Wiki commit -m "type(scope): description"
git -C /Users/aase7en/Desktop/A-Wiki push origin main
```

## 🚨 CRITICAL: `git reset --soft` CAN SILENTLY OVERWRITE GOOD CODE

**Never `git reset --soft origin/main` without inspecting remote file contents first.**

When local branch diverges from remote, `git reset --soft` stages ALL local changes on top of remote — termasuk ไฟล์ที่ local version เก่ากว่าหรือแย่กว่า ทำให้ของดีที่คนอื่น (หรือ agent อื่น) ทำไว้ถูกเขียนทับโดยไม่รู้ตัว

**Before reset:**
```bash
# Check what files differ
/usr/bin/git -C /Users/aase7en/Desktop/A-Wiki diff --name-only origin/main

# For overlapping files, inspect remote version first
/usr/bin/git -C /Users/aase7en/Desktop/A-Wiki show origin/main:path/to/file | wc -c
```

**If remote version is better → use it as base, then re-apply your changes manually.**

**If user says "มั่ว" / "เพี้ยน" / "ไม่สวยเหมือนเดิม":**
```bash
# Restore known-good version immediately
/usr/bin/git -C /Users/aase7en/Desktop/A-Wiki show <good-commit>:path/to/file > path/to/file
```

**Safe pattern:**
```bash
git fetch origin main
# INSPECT FIRST — see above
git merge origin/main  # prefer merge over reset --soft for safety
```

## 🔒 Rule 4: Pre-Commit Validation

ก่อนทุก `git commit` ใน A-Wiki:
- [ ] ไม่มี debug print statements
- [ ] ไม่มี hardcoded secrets/API keys
- [ ] `git diff --cached` ตรวจแล้ว
- [ ] Commit message: `type(scope): brief`
  - Types: `feat`, `fix`, `docs`, `refactor`, `test`, `chore`, `wiki`
- [ ] รัน `python3 scripts/check-privacy.py` ถ้าเป็นการ commit ที่มีไฟล์ใหม่

## 🔒 Rule 6: Merge Safety — Never `git reset --soft` Blindly

**🚨 CRITICAL**: เมื่อ local branch diverge จาก remote — `git reset --soft origin/main` จะเขียนทับไฟล์บน remote โดยไม่ตรวจสอบความแตกต่าง **อาจทำลาย improvements ที่ agent อื่นทำไว้**

ก่อน `git reset --soft` ทุกครั้ง:
```bash
# 1. ดูว่าไฟล์ไหน overlap กัน
git -C /Users/aase7en/Desktop/A-Wiki diff --name-only origin/main

# 2. ตรวจสอบ remote version ของไฟล์ที่ overlap
git -C /Users/aase7en/Desktop/A-Wiki show origin/main:path/to/file | head -50

# 3. ถ้า remote ดีกว่า → ใช้ remote เป็น base → re-apply เฉพาะของเรา
# 4. ถ้าของเราดีกว่าจริงๆ → ค่อย reset --soft
```

**Special rule สำหรับ UI/HTML/CSS**: Dashboard ถูก polish โดยหลาย agent — **add, don't replace** เสมอ

ดู `references/merge-safety.md` ใน `a-wiki-core` skill สำหรับขั้นตอนละเอียด + recovery recipe

```
Device 1 → commit + push → GitHub main
                          → GDrive sync .local/
Device 2 → git pull → read session-memory.md → continue
```

1. Always `git push` ก่อนเปลี่ยนเครื่อง
2. On new device: `git pull` → read `wiki/context/session-memory.md` → continue

## 🔒 Rule 6: Merge Conflict Resolution

เมื่อ remote diverged (มีคน push มาก่อน) และ `git pull --ff-only` / `git pull --rebase` fail ด้วย conflicts:

```
# ❌ อย่าทำ: force push, branch ใหม่, หรือ discard remote changes

# ✅ ทำตามนี้:
# 1. Abort การ merge/rebase ที่ค้าง
git rebase --abort   # หรือ git merge --abort

# 2. Soft-reset to remote HEAD (เก็บ changes ทั้งหมดเป็น staged)
git reset --soft origin/main

# 3. Unstage ไฟล์ที่ไม่เกี่ยวข้อง (ของคนอื่น, Kilo configs ฯลฯ)
git reset HEAD path/to/unrelated/file

# 4. Commit เฉพาะไฟล์ใน plan
git commit -m "type(scope): description"

# 5. Push
git push origin main
```

**เมื่อ conflict ในไฟล์ที่เราไม่ได้แก้**: unstage ไฟล์นั้น → ใช้ remote version → commit เฉพาะของเรา
**เมื่อ conflict ในไฟล์ที่เราแก้**: ใช้ pattern นี้เพื่อให้ changes ของเราอยู่บนสุดของ remote history

## Commit Message Format

```
type(scope): brief description

Optional body.
```

ตัวอย่าง:
- `wiki(iot): add MQTT broker entity`
- `feat(swarm): add model roster auto-update`
- `fix(dashboard): correct SSE event format`
- `chore: update model roster from OpenRouter`
