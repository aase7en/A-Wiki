---
name: a-wiki-swarm
description: "Swarm intelligence protocol from A-Wiki — dynamic model scouting, agile swarm allocation (Architect + Executioner + Senior Critic), cost-first routing. Hermes adapts the swarm protocol for delegate_task and multi-agent workflows."
version: 1.0.0
metadata:
  hermes:
    tags: [awiki, swarm, multi-agent, delegation, model-routing, cost-optimization]
---

# A-Wiki Swarm Intelligence สำหรับ Hermes

A-Wiki Swarm Protocol ปรับใช้กับ Hermes — ใช้ `delegate_task` + `web_search` + OpenRouter free models
เพื่อทำ parallel work แบบต้นทุนต่ำ โดย Hermes ทำหน้าที่ Senior Critic

## Swarm Architecture

```
┌─────────────────────────────────────────────────────────┐
│           HERMES (Senior Critic — NOT delegatable)       │
│  ─── Validates ALL outputs against Iron Laws             │
├─────────────────────────────────────────────────────────┤
│                    SWARM LAYER                            │
│  ┌─────────────────────┐  ┌─────────────────────────┐   │
│  │   ARCHITECT ROLE    │  │    EXECUTIONER ROLE      │   │
│  │ (Reasoning/CoT)     │  │  (Fast Coder/Flash Tier) │   │
│  │ - Root cause        │  │ - Code generation        │   │
│  │ - Architecture plan │  │ - Test writing           │   │
│  │ - Design decisions  │  │ - Refactoring            │   │
│  └─────────────────────┘  └─────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

## Swarm Workflow (5 ขั้นตอน)

### 1. SCOUT — หา free/cheap models ที่ใช้ได้ตอนนี้

```bash
# OpenRouter free models (ใช้ web_search หรือ web_extract)
# Query: https://openrouter.ai/api/v1/models
# Filter: models with pricing.prompt = "0" AND pricing.completion = "0"

# หรือใช้ web_search เพื่อหา models ฟรี
web_search("openrouter free models 2026 pricing zero")
```

**Scout criteria:**
- Architect: context window ≥ 128K, reasoning capability, cheap/free
- Executioner: high speed (tokens/sec), good at code, cheap/free

**Fallback**: ถ้าไม่มี free models → collapse เป็น single-agent mode (Hermes ทำเองทั้งหมด)

### 2. PLAN — Hermes สร้าง work breakdown

แบ่งงานเป็น:
- **Architect tasks**: planning, root cause, design decisions → delegate ให้ reasoning model
- **Executioner tasks**: code writing, tests, refactoring → delegate ให้ fast coder model

### 3. ALLOCATE — ส่งงานให้ subagents

```python
# Architect subagent
delegate_task(
    goal="Analyze root cause of [bug description]",
    context="Files: [paths]. Error: [message]. A-Wiki Iron Laws enforced.",
    toolsets=["terminal", "file", "web"]
)

# Executioner subagent
delegate_task(
    goal="Write failing test then fix [component]",
    context="Iron Law #1: failing test FIRST. Iron Law #2: root cause before fix.",
    toolsets=["terminal", "file"]
)
```

### 4. PARALLEL EXECUTE — รันพร้อมกัน

ใช้ `delegate_task(tasks=[...])` แบบ batch:
```python
delegate_task(tasks=[
    {"goal": "... architect task ...", "context": "...", "toolsets": ["terminal", "file", "web"]},
    {"goal": "... executioner task ...", "context": "...", "toolsets": ["terminal", "file"]},
])
```

### 5. VALIDATE — Hermes ตรวจสอบ output ทั้งหมด

- ✅ Architect's plan เคารพ Iron Laws ไหม?
- ✅ Executioner's code มี failing test ก่อน production code ไหม?
- ✅ Root cause analysis ครบ 4 ขั้นตอน debug-mantra ไหม?
- ✅ Breadcrumbs ถูก cross-reference ครบไหม?

**On violation**: DISCARD output → FLAG violation → REWRITE

## Cost-First Model Selection

Hermes ใช้หลักการนี้ในการเลือก model:

| Priority | Hermes Tool | Use for |
|----------|-------------|---------|
| **Level -1** | `terminal` → A-Wiki `search-wiki.py` | Free local FTS5 wiki search |
| **Level 1** | `web_search` → OpenRouter free roster | Free model lookup |
| **Level 2** | `delegate_task` with cheap model | Light reasoning, code gen |
| **Level 4** | Hermes primary model (you) | Complex reasoning, validation |

**Rule**: Primary agent (Hermes) = Senior Critic เสมอ — NOT delegatable. Hermes ตรวจสอบทุก output ก่อน merge

## Operational Rules

1. **No parallel execution without Iron Law validation**
2. **Architect output must include "Constraints Enforced" section**
3. **Executioner output MUST include a failing test** before production code
4. **If scouting returns zero free models** → single-agent mode
5. **Session memory updated** with swarm decisions for cross-session continuity

## Kilo Plan Execution Pattern

เมื่อพบแผนใน `.kilo/plans/*.md` (จาก Kilo AI Plan Mode) — ใช้ swarm protocol แบบ sequential (ไม่ parallel เพราะ dependency chain):

### Execution Flow
```
1. LOAD   → อ่าน plan → ดู phases + dependency order + files changed
2. PLAN   → สร้าง todo list (1 item ต่อ 1 requirement)
3. BUILD  → Implement ทีละ phase:
   a. อ่านไฟล์ที่ต้องแก้ไขก่อน (เข้าใจ current state)
   b. สร้างไฟล์ใหม่ → patch ไฟล์ที่มีอยู่
   c. หลังแต่ละ phase → update session-memory.md
4. TEST   → หลังทุก phase:
   - Syntax check (py_compile for .py)
   - Schema validation (JSON)
   - Endpoint test (Python urllib เมื่อ curl ไม่可用)
   - Start server foreground → test → kill
5. COMMIT → git add เฉพาะไฟล์ที่เกี่ยวข้อง → commit → push
6. HANDOFF → เขียน progress ใน session-memory.md → push → agent ถัดไป git pull แล้วต่อ

### Tracking Pattern
ใช้ `todo` tool แบบ granular — 1 todo ต่อ 1 requirement (ไม่ใช่ 1 todo ต่อ 1 phase):
```python
todo(todos=[
    {"id": "P1.1", "content": "Phase 1.1: ...", "status": "in_progress"},
    {"id": "P1.2", "content": "Phase 1.2: ...", "status": "pending"},
])
# merge=true เมื่อ update status:
todo(merge=True, todos=[{"id": "P1.1", "content": "...", "status": "completed"}])
```

### File Creation Workaround
บน environment ที่ `write_file` tool ล้มเหลว (PATH issue): ใช้ `/usr/bin/python3` heredocs:
