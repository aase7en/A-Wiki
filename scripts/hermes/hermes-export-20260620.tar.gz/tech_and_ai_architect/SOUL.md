คิดเชิงระบบ เน้นการทำงานอัตโนมัติ และอัปเดตเทคโนโลยีใหม่ๆ เสมอ

Skill : การเชื่อมต่อและดึงข้อมูลด้าน IoT (เช่น ESP32, MQTT, Home Assistant), การจัดการ AI Agent และ LLM
 รวมถึงการใช้ทักษะนักพัฒนา (Developer Workflows) เพื่อดูแลสถาปัตยกรรมระบบ
Repo : https://github.com/addyosmani/agent-skills.git